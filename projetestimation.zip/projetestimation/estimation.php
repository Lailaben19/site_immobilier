<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "estimation_immobiliere";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupération des données du formulaire
    $typeBien = $_POST['type_bien'];
    $ville = $_POST['ville'];
    $surfaceHabitable = floatval($_POST['surface_habitable']);
    $nombrePieces = intval($_POST['nombre_pieces']);
    $etage = intval($_POST['etage']);
    
    // Conversion des checkboxes en 0 ou 1
    $ascenseur = isset($_POST['ascenseur']) ? 1 : 0;
    $cave = isset($_POST['cave']) ? 1 : 0;
    $balcon = isset($_POST['balcon']) ? 1 : 0;
    $terrasse = isset($_POST['terrasse']) ? 1 : 0;
    $parking = isset($_POST['parking']) ? 1 : 0;
    $gardien = isset($_POST['gardien']) ? 1 : 0;
    $piscine = isset($_POST['piscine']) ? 1 : 0;
    
    $anneeConstruction = intval($_POST['annee_construction']);
    $etatBien = $_POST['etat_bien'];
    $raisonEstimation = $_POST['raison_estimation'];

    // Calcul de l'estimation (à personnaliser selon vos critères)
    $estimation = calculerEstimation(
        $typeBien,
        $ville,
        $surfaceHabitable,
        $nombrePieces,
        $etage,
        $ascenseur,
        $cave,
        $balcon,
        $terrasse,
        $parking,
        $gardien,
        $piscine,
        $anneeConstruction,
        $etatBien
    );

    // Préparation de la requête SQL
    $sql = "INSERT INTO biens_immobiliers (
        type_bien, ville, surface_habitable, nombre_pieces, etage,
        ascenseur, cave, balcon, terrasse, parking, gardien, piscine,
        annee_construction, etat_bien, raison_estimation, estimation
    ) VALUES (
        :type_bien, :ville, :surface_habitable, :nombre_pieces, :etage,
        :ascenseur, :cave, :balcon, :terrasse, :parking, :gardien, :piscine,
        :annee_construction, :etat_bien, :raison_estimation, :estimation
    )";

    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':type_bien' => $typeBien,
        ':ville' => $ville,
        ':surface_habitable' => $surfaceHabitable,
        ':nombre_pieces' => $nombrePieces,
        ':etage' => $etage,
        ':ascenseur' => $ascenseur,
        ':cave' => $cave,
        ':balcon' => $balcon,
        ':terrasse' => $terrasse,
        ':parking' => $parking,
        ':gardien' => $gardien,
        ':piscine' => $piscine,
        ':annee_construction' => $anneeConstruction,
        ':etat_bien' => $etatBien,
        ':raison_estimation' => $raisonEstimation,
        ':estimation' => $estimation
    ]);

    // Retourner le résultat en JSON
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'estimation' => $estimation,
        'message' => 'Estimation enregistrée avec succès'
    ]);

} catch(PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Erreur : ' . $e->getMessage()
    ]);
}

function calculerEstimation($typeBien, $ville, $surface, $pieces, $etage, $ascenseur, $cave, $balcon, $terrasse, $parking, $gardien, $piscine, $annee, $etat) {
    // Prix de base au m² selon la ville
    $prixBase = [
        'Bordeaux' => 4500,
        'Mérignac' => 3500,
        'Pessac' => 3300,
        'Talence' => 3400,
        'Villenave-d\'Ornon' => 3000,
        'Saint-Médard-en-Jalles' => 3200,
        'Bègles' => 3100,
        'La Teste-de-Buch' => 3800
    ];

    // Prix de base selon la ville
    $prix = $prixBase[$ville] * $surface;

    // Ajustements selon les caractéristiques
    if ($typeBien == 'maison') $prix *= 1.2;
    if ($ascenseur) $prix *= 1.05;
    if ($cave) $prix *= 1.03;
    if ($balcon) $prix *= 1.05;
    if ($terrasse) $prix *= 1.08;
    if ($parking) $prix *= 1.1;
    if ($gardien) $prix *= 1.02;
    if ($piscine) $prix *= 1.15;

    // Ajustement selon l'état
    switch ($etat) {
        case 'travaux':
            $prix *= 0.85; // Si l'état est 'travaux', on réduit l'estimation de 15%
            break;
        case 'bon':
            $prix *= 1.1; // Si l'état est 'bon', on augmente l'estimation de 10%
            break;
        case 'neuf':
            $prix *= 1.2; // Si l'état est 'neuf', on augmente l'estimation de 20%
            break;
        default:
            // Aucun ajustement si l'état est inconnu
            break;
    }
    if ($annee < 2000) {
        $prix *= 0.9; // Réduction de 10% si la construction est plus ancienne que l'an 2000
    } elseif ($annee < 2010) {
        $prix *= 1.05; // Augmentation de 5% si la construction date entre 2000 et 2010
    } elseif ($annee < 2020) {
        $prix *= 1.1; // Augmentation de 10% si la construction date entre 2010 et 2020
    } else {
        $prix *= 1.15; // Augmentation de 15% si la construction est après 2020
    }

    // Retourner l'estimation calculée
    return round($prix, 2); // Retourne l'estimation au format arrondi à 2 décimales
}
