-- Créer la base de données si elle n'existe pas déjà
CREATE DATABASE IF NOT EXISTS estimation_immobiliere;

-- Utiliser la base de données nouvellement créée
USE estimation_immobiliere;

-- Créer la table pour stocker les informations immobilières
CREATE TABLE IF NOT EXISTS biens_immobiliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_bien VARCHAR(255) NOT NULL,
    ville VARCHAR(255) NOT NULL,
    surface_habitable FLOAT NOT NULL,
    nombre_pieces INT NOT NULL,
    etage INT NOT NULL,
    ascenseur INT NOT NULL,
    cave INT NOT NULL,
    balcon INT NOT NULL,
    terrasse INT NOT NULL,
    parking INT NOT NULL,
    gardien INT NOT NULL,
    piscine INT NOT NULL,
    annee_construction INT NOT NULL,
    etat_bien VARCHAR(50) NOT NULL,
    raison_estimation VARCHAR(50) NOT NULL,
    estimation FLOAT NOT NULL
);
