<?php 
session_start();
// Récupérer les estimations à comparer depuis la base de données ou la session
$estimations = array(
    array(
        'typeBien' => 'Appartement',
        'ville' => 'Bordeaux',
        'surfaceHabitable' => 80,
        'nombrePieces' => 3,
        'etage' => 2,
        'estimation' => 300000
    ),
    array(
        'typeBien' => 'Maison',
        'ville' => 'Mérignac',
        'surfaceHabitable' => 120,
        'nombrePieces' => 5, 
        'etage' => 1,
        'estimation' => 450000
    ),
    array(
        'typeBien' => 'Appartement',
        'ville' => 'Pessac',
        'surfaceHabitable' => 65,
        'nombrePieces' => 2,
        'etage' => 4,
        'estimation' => 280000
    )
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/gironde.css">
    <title>Comparaison des estimations</title>
</head>
<body>
    <header>
        <img src="logo33.png" id="logo">
    </header>

    <div class="container">
        <h1>Comparaison des estimations</h1>

        <div class="estimation-comparison">
            <?php foreach ($estimations as $estimation) { ?>
                <div class="estimation-card">
                    <h2><?php echo $estimation['typeBien']; ?></h2>
                    <p><strong>Ville :</strong> <?php echo $estimation['ville']; ?></p>
                    <p><strong>Surface habitable :</strong> <?php echo $estimation['surfaceHabitable']; ?> m²</p>
                    <p><strong>Nombre de pièces :</strong> <?php echo $estimation['nombrePieces']; ?></p>
                    <p><strong>Étage :</strong> <?php echo $estimation['etage']; ?></p>
                    <p><strong>Estimation :</strong> <?php echo number_format($estimation['estimation'], 2); ?> €</p>
                </div>
            <?php } ?>
        </div>

        <div class="estimation-actions">
            <button onclick="saveComparison()">Sauvegarder la comparaison</button>
        </div>
    </div>

    <script>
        function saveComparison() {
            // Logique pour sauvegarder la comparaison dans le compte utilisateur
        }
    </script>
</body>
</html>
