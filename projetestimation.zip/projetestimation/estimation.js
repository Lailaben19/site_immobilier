// estimation.js

// Données sur la population des villes
var population = {
    "Bordeaux": 259809,
    "Mérignac": 74009,
    "Pessac": 65866,
    "Talence": 44359,
    "Villenave-d'Ornon": 38444,
    "Saint-Médard-en-Jalles": 32357,
    "Bègles": 30543,
    "La Teste-de-Buch": 26269
};

// Inclure les fonctions de calcul
document.write('<script src="calcul_estimation.js"></script>');

function estimer() {
    var typeBien = document.querySelector('input[name="typeBien"]:checked').value;
    var ville = document.getElementById('ville').value;
    var surfaceHabitable = parseFloat(document.getElementById('surfaceHabitable').value);
    var nombrePieces = parseInt(document.getElementById('nombrePieces').value);
    var etage = parseInt(document.getElementById('etage').value);
    var anneeConstruction = parseInt(document.getElementById('anneeConstruction').value);
    var etatBien = document.querySelector('input[name="etatBien"]:checked').value;
    var raisonEstimation = document.querySelector('input[name="raisonEstimation"]:checked').value;


    var ascenseur = document.getElementById('ascenseur').checked ? 1 : 0;
    var cave = document.getElementById('cave').checked ? 1 : 0;
    var balcon = document.getElementById('balcon').checked ? 1 : 0;
    var terrasse = document.getElementById('terrasse').checked ? 1 : 0;
    var parking = document.getElementById('parking').checked ? 1 : 0;
    var gardien = document.getElementById('gardien').checked ? 1 : 0;
    var piscine = document.getElementById('piscine').checked ? 1 : 0;

    // Appeler des fonctions séparées pour chaque partie de l'estimation
    var estimation = calculerEstimationGenerale(surfaceHabitable, nombrePieces, etage, typeBien);
    estimation = ajusterEstimationSelonAnnee(anneeConstruction, estimation);
    estimation = ajusterEstimationSelonEtatBien(etatBien, estimation);
    estimation = appliquerPoidsPopulation(ville, estimation);
    estimation = ajusterEstimationSelonRaison(raisonEstimation, estimation);

    // Afficher le résultat
    var resultatHTML = `
        <p>Type de bien: ${typeBien}</p>
        <p>Ville: ${ville}</p>
        <p>Surface habitable: ${surfaceHabitable} m²</p>
        <p>Nombre de pièces: ${nombrePieces}</p>
        <p>Étage: ${etage}</p>
        <p>Caractéristiques: Ascenseur - ${ascenseur}, Cave - ${cave}, Balcon - ${balcon}, Terrasse - ${terrasse}, Parking - ${parking}, Gardien - ${gardien}, Piscine - ${piscine}</p>
        <p>Année de construction: ${anneeConstruction}</p>
        <p>État du bien: ${etatBien}</p>
        <p>Raison de l'estimation: ${raisonEstimation}</p>
        <p>Estimation: ${estimation.toFixed(2)} euros</p>
    `;
    document.getElementById('resultat').innerHTML = resultatHTML;

    var formData = new FormData();
    formData.append('typeBien', typeBien);
    formData.append('ville', ville);
    formData.append('surfaceHabitable', surfaceHabitable);
    formData.append('nombrePieces', nombrePieces);
    formData.append('etage', etage);
    formData.append('ascenseur', ascenseur);
    formData.append('cave', cave);
    formData.append('balcon', balcon);
    formData.append('terrasse', terrasse);
    formData.append('parking', parking);
    formData.append('gardien', gardien);
    formData.append('piscine', piscine);
    formData.append('anneeConstruction', anneeConstruction);
    formData.append('etatBien', etatBien);
    formData.append('raisonEstimation', raisonEstimation);

    // Effectuer une requête AJAX vers le serveur PHP
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'enregistrer_estimation.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Traitement réussi, vous pouvez afficher une confirmation ou rediriger l'utilisateur
            console.log(xhr.responseText);
            alert(xhr.responseText); // Affichez la réponse du serveur dans une boîte d'alerte
        }
    };
    xhr.send(formData);
}