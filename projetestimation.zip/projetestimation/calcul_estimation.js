// calcul_estimation.js

function calculerEstimationGenerale(surface, pieces, etage, typeBien) {
    var estimation = surface * 2000 + pieces * 6000 + etage * 2000;

    if (typeBien === "appartement") {
        estimation += 5000;
    } else if (typeBien === "maison") {
        estimation += 20000;
    }

    return estimation;
}

function ajusterEstimationSelonAnnee(annee, estimation) {
    if (annee < 1919) {
        estimation += 5000;
    } else if (annee >= 1919 && annee <= 1945) {
        estimation += 6000;
    } else if (annee >= 1946 && annee <= 1970) {
        estimation += 7000;
    } else if (annee >= 1971 && annee <= 1990){
        estimation += 8000;
    } else if (annee >= 1991 && annee <= 2005){
        estimation += 9000;
    } else if (annee >= 2006 && annee <= 2012){
        estimation += 10000;
    }

    return estimation;
}

function ajusterEstimationSelonEtatBien(etat, estimation) {
    if (etat === "travaux") {
        estimation -= 2000;
    } else if (etat === "correct") {
        // Pas de modification pour un état correct
    } else if (etat === "neuf") {
        estimation += 3000;
    }

    return estimation;
}

function appliquerPoidsPopulation(ville, estimation) {
    var poidsPopulation = 1 + (population[ville] / 100000);
    return estimation * poidsPopulation;
}

function ajusterEstimationSelonRaison(raison, estimation) {
    if (raison === "acheter") {
        estimation *= 1.1;
    } else if (raison === "vendre") {
        estimation *= 0.9;
    }

    return estimation;
}
