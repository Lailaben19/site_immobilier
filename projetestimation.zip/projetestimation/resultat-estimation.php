
<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: formulaire-estimation.php");
    exit;
}

// Fonction de calcul d'estimation
function calculerEstimation($data) {
    $prixBase = [
        'Bordeaux' => 4800, 'Mérignac' => 3500, 'Pessac' => 3300,
        'Talence' => 3600, 'Villenave-d\'Ornon' => 3100, 
        'Saint-Médard-en-Jalles' => 3200, 'Bègles' => 3400, 'La Teste-de-Buch' => 4200
    ];
    $prixM2 = $prixBase[$data['ville']] ?? 3500;
    $surface = floatval($data['surfaceHabitable']);
    return round($prixM2 * $surface, -3);
}
$data = array_map(function($item) {
    return is_array($item) ? array_map('trim', $item) : trim($item);
}, $_POST);
$estimation = calculerEstimation($data);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/gironde.css">
    <title>Résultat de l'estimation - Burdeos Immo</title>
</head>


<nav>
        <div class="nav-container">
            <a href="accueil.php" class="logo">BURDEOS IMMO</a>
            <div class="nav-links">
                <a href="#properties">Nos Biens</a>
                <a href="formulaire-estimation.php">Estimation</a>
                <a href="contact.php">Contact</a>
            </div>
        </div>
    </nav>
</br>
</br>
</br>
</br>
<body>
    

    <main class="container">
        <div id="estimation-result" class="result-card">
            <h1>Résultat de votre estimation</h1>
            <div class="estimation-amount">
                <span class="amount"><?= number_format($estimation, 0, ',', ' ') ?> €</span>
            </div>

            <div class="property-details">
                <h2>Détails du bien</h2>
                <div class="details-grid">
                    <div class="detail-item">
                        <span class="label">Ville</span>
                        <span class="value"><?= $data['ville'] ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Surface</span>
                        <span class="value"><?= $data['surfaceHabitable'] ?> m²</span>
                    </div>
                </div>
            </div>

            <a href="formulaire-estimation.php" class="btn outline">Nouvelle estimation</a>
        </div>
    </main>
</body>
</html>

    </script>

    <style>

:root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --background-color: #f5f6fa;
            --card-color: #ffffff;
            --text-color: #2c3e50;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
        }

        /* Navigation */
        nav {
            background-color: var(--primary-color);
            padding: 1rem 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .logo {
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--secondary-color);
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
                        url('hero-image.webp') center/cover;
            height: 80vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
            margin-top: 4rem;
        }

        .hero-content {
            max-width: 800px;
            padding: 2rem;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        /* Search Section */
        .search-section {
            background: white;
            padding: 2rem;
            margin: -2rem auto 2rem;
            max-width: 1000px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }

        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .search-form select, .search-form input {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .search-button {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 0.8rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        /* Properties Grid */
        .properties {
            max-width: 1200px;
            margin: 4rem auto;
            padding: 0 2rem;
        }

        .properties h2 {
            text-align: center;
            margin-bottom: 2rem;
        }

        .properties-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
        }

        .property-card {
            background: var(--card-color);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .property-card:hover {
            transform: translateY(-5px);
        }

        .property-image {
            height: 200px;
            background: #ddd;
            position: relative;
        }

        .property-type {
            position: absolute;
            top: 1rem;
            left: 1rem;
            background: var(--secondary-color);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
        }

        .property-content {
            padding: 1.5rem;
        }

        .property-price {
            font-size: 1.5rem;
            color: var(--secondary-color);
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .property-features {
            display: flex;
            gap: 1rem;
            margin: 1rem 0;
            color: #666;
        }

        /* Estimation Section */
        .estimation {
            background: linear-gradient(135deg, var(--primary-color), #34495e);
            color: white;
            padding: 4rem 2rem;
            text-align: center;
            margin-top: 4rem;
        }

        .estimation h2 {
            margin-bottom: 1.5rem;
        }

        .btn-estimation {
            background-color: var(--secondary-color);
            color: white;
            text-decoration: none;
            padding: 1rem 2rem;
            border-radius: 50px;
            display: inline-block;
            margin-top: 1rem;
            transition: transform 0.3s;
        }

        .btn-estimation:hover {
            transform: translateY(-3px);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: column;
                gap: 1rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .search-form {
                grid-template-columns: 1fr;
            }
        }

        /* Section Carte */
.map-container {
    margin-bottom: 30px;
    text-align: center;
}

.map-wrapper {
    border-radius: 8px;
    overflow: hidden;
}



/* Footer */
footer {
    background-color: #333;
    color: #fff;
    padding: 20px;
    text-align: center;
}

footer a {
    color: #fff;
    text-decoration: none;
    margin: 0 10px;
}

footer a:hover {
    text-decoration: underline;
}

    .hidden {
        display: none;
    }

    .progress-bar {
        display: flex;
        justify-content: space-between;
        margin: 20px 0;
        padding: 0 20px;
    }

    .step {
        flex: 1;
        text-align: center;
        padding: 10px;
        background: #f0f0f0;
        position: relative;
        color: #666;
    }

    .step.active {
        background: #4CAF50;
        color: white;
    }

    .form-section {
        animation: fadeIn 0.5s;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    .loader {
        border: 5px solid #f3f3f3;
        border-top: 5px solid #4CAF50;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    .result-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        padding: 2rem;
        margin: 2rem auto;
        max-width: 800px;
    }

    .estimation-amount {
        text-align: center;
        margin: 2rem 0;
    }

    .amount {
        font-size: 3rem;
        font-weight: bold;
        color: #4CAF50;
    }

    .price-range {
        display: block;
        font-size: 1rem;
        color: #666;
        margin-top: 0.5rem;
    }

    .details-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin: 1rem 0;
    }

    .detail-item {
        background: #f5f5f5;
        padding: 1rem;
        border-radius: 8px;
    }

    .label {
        display: block;
        color: #666;
        font-size: 0.9rem;
    }

    .value {
        display: block;
        font-weight: bold;
        margin-top: 0.25rem;
    }

    .features-list {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin: 1rem 0;
    }

    .feature-tag {
        background: #e0f2e1;
        color: #4CAF50;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.9rem;
    }

    .actions {
        display: flex;
        gap: 1rem;
        margin: 2rem 0;
        justify-content: center;
    }

    .btn {
        padding: 0.75rem 1.5rem;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .btn.primary {
        background: #4CAF50;
        color: white;
    }

    .btn.secondary {
        background: #2196F3;
        color: white;
    }

    .btn.outline {
        border: 2px solid #4CAF50;
        color: #4CAF50;
        background: transparent;
    }

    .disclaimer {
        margin-top: 2rem;
        padding-top: 1rem;
        border-top: 1px solid #eee;
        font-size: 0.9rem;
        color: #666;
    }

    @media (max-width: 768px) {
        .actions {
            flex-direction: column;
        }
        
        .btn {
            width: 100%;
            justify-content: center;
        }
    }
    
    </style>
</body>
</html>