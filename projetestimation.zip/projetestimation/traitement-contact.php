<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $message = $_POST['message'];

    // Connexion à la base de données (XAMPP)
    $conn = new mysqli("localhost", "root", "", "estimation_immobiliere");

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connexion échouée : " . $conn->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO contacts (nom, email, telephone, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nom, $email, $telephone, $message);

    if ($stmt->execute()) {
        // Affichage d'un message de confirmation et redirection
        echo "
        <div style='
            max-width: 600px;
            margin: 100px auto;
            padding: 20px;
            text-align: center;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 10px;
            font-family: Arial, sans-serif;
        '>
            <h2>Merci !</h2>
            <p>Votre message a été reçu avec succès.</p>
            <p>Vous allez être redirigé vers la page d'accueil dans quelques secondes...</p>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = 'accueil.php';
            }, 5000); // Redirection après 5 secondes
        </script>
        ";
    } else {
        echo "Erreur : " . $stmt->error;
    }

    // Fermeture de la connexion
    $stmt->close();
    $conn->close();
}
?>
