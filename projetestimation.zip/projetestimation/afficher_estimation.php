<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estimation des Biens - IMMO 33</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header>
    <h1>IMMO 33 - Estimations de Biens Immobiliers</h1>
</header>

<main class="container">
    <!-- Formulaire de filtrage -->
    <section class="filter-section">
        <form method="GET" action="afficher_estimation.php">
            <label for="type">Type de bien :</label>
            <select name="type" id="type">
                <option value="">Tous</option>
                <option value="Maison">Maison</option>
                <option value="Appartement">Appartement</option>
                <option value="Terrain">Terrain</option>
                <!-- Ajoutez d'autres options selon vos types de biens -->
            </select>

            <label for="ville">Ville :</label>
            <input type="text" name="ville" id="ville" placeholder="Rechercher par ville">

            <button type="submit" class="btn-filtrer">Filtrer</button>
        </form>
    </section>

    <!-- Tableau des estimations -->
    <section class="table-section">
        <table class="estimation-table">
            <thead>
                <tr>
                    <th>Type</th>
                    <th>Ville</th>
                    <th>Surface (m²)</th>
                    <th>Nombre de pièces</th>
                    <th>Ascenseur</th>
                    <th>Cave</th>
                    <th>Balcon</th>
                    <th>Terrasse</th>
                    <th>Parking</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Construction de la requête avec les bons noms de colonnes
            $query = "SELECT * FROM biens_immobiliers WHERE 1=1";
            if (!empty($_GET['type_bien'])) {
                $query .= " AND type_bien = :type_bien";
            }
            if (!empty($_GET['ville'])) {
                $query .= " AND ville LIKE :ville";
            }

            $stmt = $conn->prepare($query);

            if (!empty($_GET['type_bien'])) {
                $stmt->bindValue(':type_bien', $_GET['type_bien']);
            }
            if (!empty($_GET['ville'])) {
                $stmt->bindValue(':ville', '%' . $_GET['ville'] . '%');
            }

            // Exécuter la requête
            $stmt->execute();

            // Affichage des données dans le tableau
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>
                    <td>" . (!empty($row['type_bien']) ? $row['type_bien'] : 'N/A') . "</td>
                    <td>" . (!empty($row['ville']) ? $row['ville'] : 'N/A') . "</td>
                    <td>" . (!empty($row['surface_habitable']) ? $row['surface_habitable'] : 'N/A') . "</td>
                    <td>" . (!empty($row['nombre_pieces']) ? $row['nombre_pieces'] : 'N/A') . "</td>
                    <td>" . (!empty($row['ascenseur']) ? 'Oui' : 'Non') . "</td>
                    <td>" . (!empty($row['cave']) ? 'Oui' : 'Non') . "</td>
                    <td>" . (!empty($row['balcon']) ? 'Oui' : 'Non') . "</td>
                    <td>" . (!empty($row['terrasse']) ? 'Oui' : 'Non') . "</td>
                    <td>" . (!empty($row['parking']) ? 'Oui' : 'Non') . "</td>
                </tr>";
            }

                
                ?>
            </tbody>
        </table>
    </section>
</main>

<footer>
    <p>&copy; 2024 IMMO 33 - Tous droits réservés.</p>
</footer>

</body>
</html>













