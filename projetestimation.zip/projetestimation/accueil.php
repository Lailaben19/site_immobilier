<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BURDEOS IMMO - Agence Immobilière</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --background-color: #f5f6fa;
            --card-color: #ffffff;
            --text-color: #2c3e50;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
        }

        /* Navigation */
        nav {
            height: 60px; /* Ajuste la hauteur de la nav */

            background-color: var(--primary-color);
            width: 100%;
            z-index: 1000;

            margin: 0; /* Supprime la marge par défaut autour de la nav */
            padding: 0; /* Supprime les padding éventuels */
        }

        .nav-container {
    max-width: 1400px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 2rem;
}

.logo {
    display: flex;
    align-items: center; /* Assure que le logo est bien centré verticalement */
    color: white;
    font-size: 0.5rem;
    font-weight: bold;
    text-decoration: none;
}

.logo-img {
    height: 60px; /* Ajustez la hauteur du logo */
    max-width: 100%; /* Empêche le dépassement horizontal */
    
}



        

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--secondary-color);
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
                        url('ph.jpg') center/cover;
            height: 85vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;

            margin-top: 0; /* Enlève l'espace au-dessus de la section hero */
            padding: 0; /* Si la section hero a un padding, le retirer */
        }

        .hero-content {
            max-width: 800px;
            padding: 2rem;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        /* Search Section */
        .search-section {
            background: white;
            padding: 2rem;
            margin: -2rem auto 2rem;
            max-width: 1000px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }

        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .search-form select, .search-form input {
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .search-button {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 0.8rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

                /* Style de la carte principale */
        .property-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 20px;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        /* Container de l'image */
        .property-image {
            position: relative;
            height: 200px; /* Hauteur fixe pour l'image */
            width: 100%;
        }

        /* Style de l'image */
        .property-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block; /* Empêche l'espace blanc sous l'image */
        }

        /* Badge du type de propriété */
        .property-type {
            position: absolute;
            top: 10px;
            left: 10px;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            z-index: 1; /* Assure que le type reste visible */
        }

        /* Container du contenu */
        .property-content {
            padding: 15px;
            background: white; /* Fond blanc pour le contenu */
        }

        /* Style du prix */
        .property-price {
            font-size: 1.25rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 8px;
        }

        /* Style du titre (location) */
        .property-content h3 {
            margin: 8px 0;
            color: #34495e;
        }

        /* Style des caractéristiques */
        .property-features {
            display: flex;
            gap: 15px;
            color: #7f8c8d;
        }

        .property-features span {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Style des icônes */
        .property-features i {
            color: #3498db;
        }

        /* Style pour rendre les cartes responsive */
        @media (max-width: 768px) {
            .property-image {
                height: 150px; /* Image plus petite sur mobile */
            }
            
            .property-features {
                flex-direction: column;
                gap: 8px;
            }
        }

        /* Properties Grid */
        .properties {
            max-width: 1200px;
            margin: 4rem auto;
            padding: 0 2rem;
        }

        .properties h2 {
            text-align: center;
            margin-bottom: 2rem;
        }

        .properties-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
        }



        /* Estimation Section */
        .estimation {
            background: linear-gradient(135deg, var(--primary-color), #34495e);
            color: white;
            padding: 4rem 2rem;
            text-align: center;
            margin-top: 4rem;
        }

        .estimation h2 {
            margin-bottom: 1.5rem;
        }

        

    

        .btn-estimation {
            background-color: var(--secondary-color);
            color: white;
            text-decoration: none;
            padding: 1rem 2rem;
            border-radius: 50px;
            display: inline-block;
            margin-top: 1rem;
            transition: transform 0.3s;
        }

        .btn-estimation:hover {
            transform: translateY(-3px);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .nav-container {
                flex-direction: column;
                gap: 1rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .search-form {
                grid-template-columns: 1fr;
            }
        }


                /* Style pour rendre les cartes responsive */
        @media (max-width: 768px) {
            .property-image {
                height: 150px; /* Image plus petite sur mobile */
            }
            
            .property-features {
                flex-direction: column;
                gap: 8px;
            }

            

         

        .map-wrapper {
            border-radius: 8px;
            overflow: hidden;
        }

    
        map-container h2 {
            display: block;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
            margin-bottom: 2rem;
  
}

       


/* Autres styles pour la navigation restent inchangés */



    </style>
</head>
<body>



    <nav>
        <div class="nav-container">
            <a href="accueil.php" class="logo">
            <img src="logo.png" alt="Logo" class="logo-img">
            </a>
            <div class="nav-links">
                <a href="#properties">Nos Biens</a>
                <a href="formulaire-estimation.php">Estimation</a>
                <a href="contact.php">Contact</a>
            </div>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content">
        <h2>Trouvez votre bien idéal à Bordeaux et ses alentours</h2>
<p>Explorez notre sélection exclusive de biens à l'achat ou à la location, adaptés à tous vos projets de vie.</p>

        </div>
    </section>
  
    

    <section class="properties" id="properties">
        <h2>Nos Biens</h2>
        <div class="properties-grid">
            <?php
            // Exemple de boucle pour afficher les biens
            // À remplacer par votre logique de base de données
            $properties = [
                [
                    'type' => 'Appartement',
                    'price' => '250 000 €',
                    'location' => 'Bordeaux Centre',
                    'image' => 'images/image1.jpg',
                    'rooms' => 3,
                    'area' => 75
                ],

                [
                    'type' => 'Maison',
                    'price' => '900 000 €',
                    'location' => 'Mérignac Centre',
                    'image' => 'images/image2.jfif',
                    'rooms' => 5,
                    'area' => 80
                    
                ],

                [
                    'type' => 'Maison',
                    'price' => '900 000 €',
                    'location' => 'Mérignac Centre',
                    'image' => 'images/image3.jfif',
                    'rooms' => 5,
                    'area' => 80
                ],
                [
                    'type' => 'Appartement',
                    'price' => '250 000 €',
                    'location' => 'Bordeaux Bastide',
                    'image' => 'images/image4.jfif',
                    'rooms' => 3,
                    'area' => 65
                ],
                [
                    'type' => 'Maison',
                    'price' => '1 200 000 €',
                    'location' => 'Pessac Alouette',
                    'image' => 'images/image6.jfif',
                    'rooms' => 7,
                    'area' => 150
                ],
                [
                    'type' => 'Terrain',
                    'price' => '300 000 €',
                    'location' => 'Le Haillan',
                    'image' => 'images/image5.jfif',
                    'rooms' => 0,  // Pas de chambres pour un terrain
                    'area' => 500
                ],
                [
                    'type' => 'Appartement',
                    'price' => '450 000 €',
                    'location' => 'Mérignac Capeyron',
                    'image' => 'images/image7.jfif',
                    'rooms' => 4,
                    'area' => 95
                ],
                [
                    'type' => 'Maison',
                    'price' => '800 000 €',
                    'location' => 'Bordeaux Caudéran',
                    'image' => 'images/image8.jfif',
                    'rooms' => 6,
                    'area' => 120
                ],
                [
                    'type' => 'Appartement',
                    'price' => '450 000 €',
                    'location' => 'Mérignac Capeyron',
                    'image' => 'images/image7.jfif',
                    'rooms' => 4,
                    'area' => 95
                ]


               
            ];

        foreach ($properties as $property): ?>

        <div class="property-card">
            <div class="property-image">
                <!-- Option 1 : Image avec fallback en cas d'erreur -->
                <img src="<?php echo htmlspecialchars($property['image']); ?>"
                    alt="<?php echo htmlspecialchars($property['type']); ?>"
                    onerror="this.src='images/default.jpg';">
                    
                <span class="property-type"><?php echo htmlspecialchars($property['type']); ?></span>
            </div>
            <div class="property-content">
                <div class="property-price"><?php echo htmlspecialchars($property['price']); ?></div>
                <h3><?php echo htmlspecialchars($property['location']); ?></h3>
                <div class="property-features">
                    <span><i class="fas fa-bed"></i> <?php echo htmlspecialchars($property['rooms']); ?> pièces</span>
                    <span><i class="fas fa-ruler-combined"></i> <?php echo htmlspecialchars($property['area']); ?> m²</span>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </section>
        <!-- Contenu principal -->
        <main class="container">

        <h2 style="color: rgb(0, 0, 0)" align="center">Localisation des biens à Bordeaux et aux alentours</h2>

        <section class="map-container" id="map-container">
        </br>
        <div class="map-wrapper">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d182802.08563842227!2d-0.6401877!3d44.84044505!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd5527e8f751ca81%3A0x796386d2dc88a6d!2sBordeaux!5e0!3m2!1sfr!2sfr!4v1701438838507!5m2!1sfr!2sfr" 
            width="55%" height="550" style="border:0;margin-left: 22%; margin-right: 5%; border-radius: 8px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

            
            <!-- Section Estimation -->
            <section class="estimation">
                <h2>Estimation Gratuite de Votre Bien</h2>
                <p>Obtenez une estimation précise de votre bien immobilier en quelques minutes et découvrez son véritable potentiel sur le marché.</p>
                <a href="formulaire-estimation.php" class="btn-estimation">Estimer mon bien</a>
            </section>

        </main>






    <script>
        // Script pour gérer le comportement de la navigation fixe
        window.addEventListener('scroll', function() {
            const nav = document.querySelector('nav');
            if (window.scrollY > 50) {
                nav.style.background = 'rgba(44, 62, 80, 0.95)';
            } else {
                nav.style.background = 'var(--primary-color)';
            }
        });
    </script>

    <footer style="background-color: #34495e; color: #fff; text-align: center; padding: 20px 0;">
        <div class="footer-content">
            <h5 style="margin: 5px 0;">&copy; 2024 BURDEOS IMMO - Tous droits réservés.</h5>
            <h6 style="margin: 5px 0;">
                <a href="contact.php" style="color: 	#FF0000; text-decoration: none; font-weight: bold;"
                   onmouseover="this.style.textDecoration='underline';"
                   onmouseout="this.style.textDecoration='none';">
                   Nous contacter
                </a>
            </h6>
        </div>
    </footer>

</body>
</html>