<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - BURDEOS IMMO</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #e74c3c;
            --background-color: #f5f6fa;
            --text-color: #2c3e50;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
        }

        nav {
            background-color: var(--primary-color);
            padding: 1rem 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .logo {
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--secondary-color);
        }

        .contact-section {
            max-width: 800px;
            margin: 6rem auto 2rem;
            background-color: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .contact-section h2 {
            text-align: center;
            margin-bottom: 2rem;
        }

        .contact-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .contact-form button {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .contact-form button:hover {
            background-color: #c0392b;
        }

        .contact-info {
            text-align: center;
            margin-top: 2rem;
        }

        .contact-info p {
            margin: 0.5rem 0;
        }

        footer {
            background-color: var(--primary-color);
            color: #fff;
            padding: 1.5rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-container">
            <a href="accueil.php" class="logo">BURDEOS IMMO</a>
            <div class="nav-links">
                <a href="accueil.php">Accueil</a>
                <a href="formulaire-estimation.php">Estimation</a>
                <a href="contact.php">Contact</a>
            </div>
        </div>
    </nav>

    <section class="contact-section">
        <h2>Contactez-nous</h2>
        <form class="contact-form" action="traitement-contact.php" method="POST">
            <input type="text" name="nom" placeholder="Votre nom" required>
            <input type="email" name="email" placeholder="Votre adresse e-mail" required>
            <input type="tel" name="telephone" placeholder="Votre numéro de téléphone">
            <textarea name="message" rows="5" placeholder="Votre message" required></textarea>
            <button type="submit">Envoyer le message</button>
        </form>
        <div class="contact-info">
            <p><i class="fas fa-map-marker-alt"></i> 123 Rue de Bordeaux, 33000 Bordeaux, France</p>
            <p><i class="fas fa-envelope"></i> contact@burdeosimmo.fr</p>
            <p><i class="fas fa-phone"></i> +33 5 56 00 00 00</p>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 BURDEOS IMMO - Tous droits réservés.</p>
    </footer>
</body>
</html>
